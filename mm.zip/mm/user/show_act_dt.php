  <?php
    require_once '../condb.php';
    // $sql = "SELECT persons.*, tb_users.* FROM persons LEFT JOIN tb_users ON persons.id = tb_users.person_id";
    $sql = "SELECT
    activities.id,
    activities.title,
    activities.start_date,
    activities.end_date,
    refs.title AS category
    FROM
    activities
    LEFT JOIN refs ON activities.category_id = refs.id";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $index = 1;

        ?>


    <link rel="stylesheet" href="https://cdn.datatables.net/2.1.2/css/dataTables.dataTables.min.css">

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
          <div class="container-fluid">
              <div class="row mb-2">
                <h1>เเสดงข้อมูลกิจกรรม</h1>
              </div>
          </div><!-- /.container-fluid -->
      </section>


      <!-- Main content -->
      <div class="card">
          <!-- /.card-header -->
          <div class="card-body">
              <table class="table" id="tb_users">
                  <thead>
                      <tr>
                          <th>ลำดับ</th>
                          <th>ชื่อกิจกรรม</th>
                          <th>หมวดหมู่</th>
                          <th>วันเริ่มต้น</th>
                          <th>วันสิ้นสุด</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php foreach ($activities as $act) : ?>
                          <tr>
                              <!-- <td><?php echo $us['id']; ?></td> -->
                              <td><?php echo $index; ?></td>
                              <td><?php echo $act['title']; ?></td>
                              <td><?php echo $act['category']; ?></td>
                              <td><?php echo $act['start_date']; ?></td>
                              <td><?php echo $act['end_date']; ?></td>
                          </tr>
                          <?php $index++ ?>
                      <?php endforeach; ?>
                  </tbody>
              </table>
          </div>
          <!-- /.card-body -->
      </div>
      <!-- /.card -->
  </div>
  <!-- /.col -->
  </div>
  <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
  <script src="https://cdn.datatables.net/2.1.2/js/dataTables.min.js"></script>
  <script>
      let table = new DataTable('#userTable');
  </script>