   <?php
require_once '../condb.php';
// SQL ส าหรับการนับจ านวนผู้ใช้ที่ลงทะเบียน
$sql = "SELECT COUNT(*) AS total_users FROM tb_users";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);
// ดึงค่าจา นวนผใู้ชท้ ี่ลงทะเบียน
$total_users = $result['total_users'];

// สำหรับนับจำนวนคลับ

$sql_clubs = "SELECT COUNT(*) AS total_clubs FROM clubs";

$stmt = $conn->prepare($sql_clubs);
$stmt->execute();
$result_clubs = $stmt->fetch(PDO::FETCH_ASSOC);
// ดึงค่าจา นวนผใู้ชท้ ี่ลงทะเบียน
$total_clubs = $result_clubs['total_clubs'];
//สำหรับ
$sql_training= "SELECT COUNT(*) AS total_training FROM activities WHERE category_id = 401";

$stmt = $conn->prepare($sql_training);
$stmt->execute();
$result_training = $stmt->fetch(PDO::FETCH_ASSOC);
// ดึงค่าจา นวนผใู้ชท้ ี่ลงทะเบียน
$total_training = $result_training['total_training'];

$sql_meeting= "SELECT COUNT(*) AS total_meeting FROM activities WHERE category_id = 402";

$stmt = $conn->prepare($sql_meeting);
$stmt->execute();
$result_meeting = $stmt->fetch(PDO::FETCH_ASSOC);
// ดึงค่าจา นวนผใู้ชท้ ี่ลงทะเบียน
$total_meeting = $result_meeting['total_meeting'];
?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard v1</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h3>
                <?php echo $total_clubs; ?>
                </h3>

                <p>Clubs</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3>
                  <?php echo $total_training; ?>
                </h3>

                <p>Training</p>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h3>
                  <?php echo $total_meeting; ?>
              </h3>

                <p>Meeting</p>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3>
                  <?php echo $total_users; ?>
                </h3>

                <p>User Registrations</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="show_member.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <!-- ./col -->
        </div>
        <!-- /.row -->

      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->